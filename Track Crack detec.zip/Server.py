# server.py

from flask import Flask, request, jsonify       # Flask for server, request for receiving data, jsonify for structured JSON responses
import pandas as pd                             # pandas for working with CSV files
import os                                       # os for file system operations
from datetime import datetime                   # datetime to generate timestamp for each row
import threading                                # threading to manage safe concurrent file writes
import logging                                  # logging to track events and errors

app = Flask(__name__)                           # Create a Flask web application
CSV_FILE = 'sensor_data.csv'                    # Name of the CSV file to store sensor data
LOCK = threading.Lock()                         # A threading lock to ensure thread-safe write operations

# Setup logging format and level
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Create the CSV file if it doesn't already exist, with proper headers
def initialize_csv():
    if not os.path.isfile(CSV_FILE):
        # Define column headers
        df = pd.DataFrame(columns=['timestamp', 'ir1', 'ir2', 'ultrasonic'])
        df.to_csv(CSV_FILE, index=False)        # Write empty DataFrame to CSV
        logging.info(f"Created new CSV file: {CSV_FILE}")

initialize_csv()                                 # Ensure CSV is initialized when server starts

# Define a route to receive data from ESP via POST request
@app.route('/data', methods=['POST'])
def receive_data():
    client_ip = request.remote_addr             # Get IP address of client (e.g., ESP32)
    
    try:
        # Try to parse incoming JSON payload from the request
        data = request.get_json(force=True)

        # Ensure that all required keys are present in the received data
        required_keys = ['ir1', 'ir2', 'ultrasonic']
        if not all(key in data for key in required_keys):
            logging.warning(f"Missing keys in request from {client_ip}: {data}")
            return jsonify({
                'status': 'error',
                'message': 'Missing one or more required fields: ir1, ir2, ultrasonic'
            }), 400  # Return HTTP 400 Bad Request

        # Create a row dictionary with a timestamp and the sensor data
        row = {
            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'ir1': data['ir1'],
            'ir2': data['ir2'],
            'ultrasonic': data['ultrasonic']
        }

        # Thread-safe writing to CSV to prevent simultaneous write errors
        with LOCK:
            df = pd.DataFrame([row])            # Convert row dict to a single-row DataFrame
            df.to_csv(CSV_FILE, mode='a', header=False, index=False)  # Append to CSV

        # Log the successful data saving
        logging.info(f"Data saved from {client_ip}: {row}")
        return jsonify({'status': 'success', 'message': 'Data recorded'}), 200  # Return HTTP 200 OK

    except Exception as e:
        # Log any exceptions that occur during request handling
        logging.error(f"Error processing request from {client_ip}: {e}")
        return jsonify({'status': 'error', 'message': 'Internal Server Error'}), 500  # Return HTTP 500

# Run the Flask app on all available network interfaces at port 5000
# 'threaded=True' allows Flask to handle multiple requests concurrently
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, threaded=True)
    
# to run : gunicorn -w 4 -b 0.0.0.0:5000 server:app